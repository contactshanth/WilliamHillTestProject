package step_definitions;

import static org.testng.AssertJUnit.assertEquals;
import static pageobjects.HomePage.Balance;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import modules.BetSlip;
import modules.SignInAction;
import modules.SignoutAction;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pageobjects.AutomationHomePage;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import pageobjects.AutomationHomePage;
import pageobjects.Config;
import pageobjects.HomePage;
import pageobjects.LoginPage;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class WilliamHillSports{
    public WebDriver driver;
    
    public WilliamHillSports()
    {
    	driver = Hooks.driver;
    }
    

    @Given("^user is on WilliamHill Sports website$")
    public void userIsOnWilliamHillSportsWebsite() throws Throwable {

        driver.get(Config.baseUrl);


    }

    @When("^Login to the William Hill Sport Site url with \"([^\"]*)\" and \"([^\"]*)\"$")
    public void loginToTheWilliamHillSportSiteUrlWithAnd(String username, String password) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        PageFactory.initElements(driver, AutomationHomePage.class);
        PageFactory.initElements(driver, LoginPage.class);

        SignInAction.Execute(driver, username, password);

        //throw new PendingException();
    }

    @And("^Navigate to \"([^\"]*)\" and Add Select First Active to the Betslip with \"([^\"]*)\"$")
    public void navigateToAndAddSelectFirstActiveToTheBetslipWith(String SportEvent, String Price) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        //String Balance_Before  = HomePage.Balance.getText();
        PageFactory.initElements(driver, AutomationHomePage.class);
        PageFactory.initElements(driver, LoginPage.class);
        String return_Value = BetSlip.BetSlip_Event(driver, SportEvent, Price);
        Assert.assertNotNull(return_Value);
        String return_Stake = BetSlip.Return_Stake();
        Assert.assertNotNull(return_Stake);


    }

    @Then("^Verify the User Balance reduced \"([^\"]*)\" amount$")
    public void verifyTheUserBalanceReducedAmount(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
       String Bal = HomePage.Balance.getText();
       Assert.assertNotSame(Bal, Balance);
        SignoutAction.Execute(driver);

    }
}