package modules;

import helpers.Log;
import oracle.jrockit.jfr.events.EventHandlerImpl;
import org.apache.xmlbeans.impl.xb.xsdschema.FieldDocument;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import pageobjects.HomePage;
import pageobjects.LoginPage;
import sun.java2d.Spans;


public class BetSlip {

	public static String BetSlip_Event(WebDriver driver, String SportsEvent, String Price) throws Exception{

		Thread.sleep(3000);

		driver.findElement(By.cssSelector("#OB_OU1498321362")).click();

		Thread.sleep(2000);
		driver.findElement(By.cssSelector("#stake-input__1498321362L")).clear();
		driver.findElement(By.cssSelector("#stake-input__1498321362L")).sendKeys(Price);
		String Value = driver.findElement(By.cssSelector("#estimated-returns_1498321362L > span")).getText();
		return Value;

	}


	public static String Return_Stake() throws Exception{


			String Total_Stake = HomePage.Total_St.getText();
			return Total_Stake;
		}

}
