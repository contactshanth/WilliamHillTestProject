package pageobjects;
import helpers.Log;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
public class AutomationHomePage extends BaseClass{

	public AutomationHomePage(WebDriver driver){
		super(driver);
	}

	@FindBy(how=How.CSS, using="span.sb-translate")
	public static WebElement login_Button;

	@FindBy(how=How.LINK_TEXT, using="Sign in")
	public static WebElement sign_in;

	
	@FindBy(how=How.LINK_TEXT, using="logoutLink")
	public static WebElement sign_out;

	@FindBy(how=How.CSS, using = "sb-translate")
    public static WebElement Account_Link;
	
}
		

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	