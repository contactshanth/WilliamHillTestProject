package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;
import helpers.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;

public class HomePage extends BaseClass{
	
	public HomePage(WebDriver driver)
	{
		super(driver);
	}


	@FindBy(how=How.CLASS_NAME, using="#OB_OU1498321362\"")
	public static WebElement FootBall_Event;

	@FindBy(how=How.LINK_TEXT, using = "No Thanks")
	public static Select Unexpected_Window;

	@FindBy(how=How.CSS, using = "btmarket__link-name")
	public static WebElement Latest_FootBall_Event;

	@FindBy(how=How.CLASS_NAME, using="#stake-input__1498321362L")
	public static WebElement BetSlip_Text;
	
	@FindBy(how=How.CLASS_NAME, using="#estimated-returns_1498321362L > span")
	public static WebElement return_Amt;

	@FindBy(how=How.ID, using="total-stake-price")
	public static WebElement Total_St;
	
	@FindBy(how=How.ID, using="userBalance")
	public static WebElement Balance;


}
