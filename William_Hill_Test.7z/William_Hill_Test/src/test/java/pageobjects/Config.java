package pageobjects;

/**
 * contains a number of constants which can be set as arguments into the program
 * else uses default values and runs locally
 */
public interface Config {

    String baseUrl        = System.getProperty("baseUrl", "https://sports.williamhill.com/sr-admin-set-white-list-cookie.html"); //2nd param is the default to use
    //String browser        = System.getProperty("browser", "ChromeDriver");




}